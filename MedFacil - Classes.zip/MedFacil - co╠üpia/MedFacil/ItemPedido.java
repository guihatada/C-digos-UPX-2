
package MedFacil.java;

public class ItemPedido {
    private Medicamento medicamento;
    private int quantidade;

    public ItemPedido(Medicamento medicamento, int quantidade) {
        this.medicamento = medicamento;
        this.quantidade = quantidade;
    }

    public Medicamento getMedicamento() {
        return medicamento;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getValorTotal() {
        return medicamento.getPreco() * quantidade;
    }

    @Override
    public String toString() {
        return medicamento.getNome() + " x" + quantidade + " = R$ " + getValorTotal();
    }
}